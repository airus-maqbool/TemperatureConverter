function convertTemperature() {
    const temp = parseFloat(document.getElementById('temperature').value);
    const inputUnit = document.getElementById('input-unit').value;
    const outputUnit = document.getElementById('output-unit').value;
    let convertedTemp;

    if (isNaN(temp)) {
        alert("Please enter a valid number for temperature");
        return;
    }

    if (inputUnit === outputUnit) {
        convertedTemp = temp;
    } else {
        switch(inputUnit) {
            case 'celsius':
                if (outputUnit === 'fahrenheit') {
                    convertedTemp = (temp * 9/5) + 32;
                } else if (outputUnit === 'kelvin') {
                    convertedTemp = temp + 273.15;
                }
                break;
            case 'fahrenheit':
                if (outputUnit === 'celsius') {
                    convertedTemp = (temp - 32) * 5/9;
                } else if (outputUnit === 'kelvin') {
                    convertedTemp = ((temp - 32) * 5/9) + 273.15;
                }
                break;
            case 'kelvin':
                if (outputUnit === 'celsius') {
                    convertedTemp = temp - 273.15;
                } else if (outputUnit === 'fahrenheit') {
                    convertedTemp = ((temp - 273.15) * 9/5) + 32;
                }
                break;
        }
    }

    document.getElementById('result').innerHTML = `${convertedTemp.toFixed(2)} ${outputUnit === 'celsius' ? '°C' : outputUnit === 'fahrenheit' ? '°F' : 'K'}`;
}
